﻿Imports System.Net.NetworkInformation

Public Class Form3
    Dim Connection As NetworkInterface
    Dim ConnectList As NetworkInterface()
    Dim StatisticsConnect As IPv4InterfaceStatistics
    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Location = New Drawing.Point(Screen.PrimaryScreen.WorkingArea.Right - 190, 40)
        ConnectList = NetworkInterface.GetAllNetworkInterfaces()
        
  
    End Sub
    Dim BytesSent As Long = 0, BytesRec As Long = 0
    Dim Received As Double = 0, Sent As Double = 0, AllTraffic As Double = 0

    Private Sub Tmr_Tick(sender As Object, e As EventArgs) Handles Tmr.Tick
        Try
            Connection = ConnectList(Metro_UIvb.Label1.Text)
        Catch ex As Exception
            Connection = ConnectList(0)
        End Try
        StatisticsConnect = Connection.GetIPv4Statistics()
        ' Статистика для нашего подключения(IPV4)
        StatisticsConnect = Connection.GetIPv4Statistics()
        ' Вычисляем скорость передачи
        Dim TransferRate As Integer
        TransferRate = CInt((Math.Truncate(StatisticsConnect.BytesSent - Double.Parse(BytesSent))) \ 100)
        ' Вычисляем скорость приема
        Dim ReceptionRate As Integer
        ReceptionRate = CInt((Math.Truncate(StatisticsConnect.BytesReceived - Double.Parse(BytesRec))) \ 100)
        ' Значения в байтах
        BytesSent = StatisticsConnect.BytesSent
        BytesRec = StatisticsConnect.BytesReceived
        ' Принято Мб
        Received = Val(StatisticsConnect.BytesReceived) / Val(1024) / Val(1024)
        ' Отдано Мб
        Sent = Val(StatisticsConnect.BytesSent) / Val(1024) / Val(1024)
        ' Весь трафик
        AllTraffic = Val(StatisticsConnect.BytesReceived) / Val(1024) / Val(1024) + Val(StatisticsConnect.BytesSent) / Val(1024) / Val(1024)
        If AllTraffic >= 1000 Then
            AllTraffic = AllTraffic / 1024
            MetroLabel3.Text = Math.Round(AllTraffic, 2) & " Гб"
        Else
            MetroLabel3.Text = Math.Round(AllTraffic, 2) & " Мб"

        End If
        ' Скорость передачи
        MetroLabel1.Text = TransferRate.ToString() & " Кбит/с"
        ' Скорость передачи
        MetroLabel2.Text = ReceptionRate.ToString() & " Кбит/с"
    End Sub


    Private Sub Form3_Click(sender As Object, e As EventArgs) Handles MyBase.Click
        Metro_UIvb.Show()
        Metro_UIvb.Focus()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Metro_UIvb.Show()
        Metro_UIvb.Focus()
    End Sub
    Dim pushed As Boolean = False
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If pushed = False Then
            Me.Size = New System.Drawing.Size(Me.Size.Width, 100)
            Panel1.Location = New Drawing.Point(0, 0)
            pushed = True
            Button1.Text = "u"
            Me.TopMost = True
        Else
            Me.Size = New System.Drawing.Size(Me.Size.Width, 257)
            Panel1.Location = New Drawing.Point(0, 158)
            pushed = False
            Button1.Text = "t"
            Me.TopMost = False

        End If
        

    End Sub
End Class