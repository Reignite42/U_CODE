﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Форма переопределяет dispose для очистки списка компонентов.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Является обязательной для конструктора форм Windows Forms
    Private components As System.ComponentModel.IContainer

    'Примечание: следующая процедура является обязательной для конструктора форм Windows Forms
    'Для ее изменения используйте конструктор форм Windows Form.  
    'Не изменяйте ее в редакторе исходного кода.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Tmr = New System.Windows.Forms.Timer(Me.components)
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.LbSpeedPr = New System.Windows.Forms.Label()
        Me.LbSpedPe = New System.Windows.Forms.Label()
        Me.LbSent = New System.Windows.Forms.Label()
        Me.LbRec = New System.Windows.Forms.Label()
        Me.LbTraffic = New System.Windows.Forms.Label()
        Me.LbSpeed = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ComboBox1
        '
        Me.ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(12, 12)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(429, 21)
        Me.ComboBox1.TabIndex = 0
        '
        'Tmr
        '
        Me.Tmr.Interval = 500
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.LbSpeedPr)
        Me.GroupBox1.Controls.Add(Me.LbSpedPe)
        Me.GroupBox1.Controls.Add(Me.LbSent)
        Me.GroupBox1.Controls.Add(Me.LbRec)
        Me.GroupBox1.Controls.Add(Me.LbTraffic)
        Me.GroupBox1.Controls.Add(Me.LbSpeed)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 39)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(429, 163)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Статистика"
        '
        'LbSpeedPr
        '
        Me.LbSpeedPr.AutoSize = True
        Me.LbSpeedPr.Location = New System.Drawing.Point(15, 137)
        Me.LbSpeedPr.Name = "LbSpeedPr"
        Me.LbSpeedPr.Size = New System.Drawing.Size(102, 13)
        Me.LbSpeedPr.TabIndex = 5
        Me.LbSpeedPr.Text = "Скорость приема :"
        '
        'LbSpedPe
        '
        Me.LbSpedPe.AutoSize = True
        Me.LbSpedPe.Location = New System.Drawing.Point(15, 115)
        Me.LbSpedPe.Name = "LbSpedPe"
        Me.LbSpedPe.Size = New System.Drawing.Size(111, 13)
        Me.LbSpedPe.TabIndex = 4
        Me.LbSpedPe.Text = "Скорость передачи :"
        '
        'LbSent
        '
        Me.LbSent.AutoSize = True
        Me.LbSent.Location = New System.Drawing.Point(15, 92)
        Me.LbSent.Name = "LbSent"
        Me.LbSent.Size = New System.Drawing.Size(63, 13)
        Me.LbSent.TabIndex = 3
        Me.LbSent.Text = "Передано :"
        '
        'LbRec
        '
        Me.LbRec.AutoSize = True
        Me.LbRec.Location = New System.Drawing.Point(15, 70)
        Me.LbRec.Name = "LbRec"
        Me.LbRec.Size = New System.Drawing.Size(56, 13)
        Me.LbRec.TabIndex = 2
        Me.LbRec.Text = "Принято :"
        '
        'LbTraffic
        '
        Me.LbTraffic.AutoSize = True
        Me.LbTraffic.Location = New System.Drawing.Point(15, 48)
        Me.LbTraffic.Name = "LbTraffic"
        Me.LbTraffic.Size = New System.Drawing.Size(78, 13)
        Me.LbTraffic.TabIndex = 1
        Me.LbTraffic.Text = "Весь трафик :"
        '
        'LbSpeed
        '
        Me.LbSpeed.AutoSize = True
        Me.LbSpeed.Location = New System.Drawing.Point(15, 25)
        Me.LbSpeed.Name = "LbSpeed"
        Me.LbSpeed.Size = New System.Drawing.Size(61, 13)
        Me.LbSpeed.TabIndex = 0
        Me.LbSpeed.Text = "Скорость :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(292, 137)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Label1"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(451, 208)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.ComboBox1)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.Text = "Подключение"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Tmr As System.Windows.Forms.Timer
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents LbSpeedPr As System.Windows.Forms.Label
    Friend WithEvents LbSpedPe As System.Windows.Forms.Label
    Friend WithEvents LbSent As System.Windows.Forms.Label
    Friend WithEvents LbRec As System.Windows.Forms.Label
    Friend WithEvents LbTraffic As System.Windows.Forms.Label
    Friend WithEvents LbSpeed As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label

End Class
