﻿Imports System.Net.NetworkInformation
Public Class Form1
    Dim Connection As NetworkInterface
    Dim ConnectList As NetworkInterface()
    Dim StatisticsConnect As IPv4InterfaceStatistics
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Получаем все подключения
        ConnectList = NetworkInterface.GetAllNetworkInterfaces()
        ' Добавляем имена подключений в ComboBox
        For Each i As NetworkInterface In ConnectList
            If Not i.NetworkInterfaceType = NetworkInterfaceType.Loopback Then
                ComboBox1.Items.Add(i.Name)
            End If
        Next
    End Sub
    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        ' Работаем с активным подключением
        Connection = ConnectList(sender.selectedindex)
        ' Скорость
        LbSpeed.Text = "Скорость : " & Val(Connection.Speed) / Val(1000000) & " Мбит/с" ' Скорость в Мб/с
        ' Тик статистики
        Tmr.Start()
    End Sub
    Dim BytesSent As Long = 0, BytesRec As Long = 0
    Dim Received As Double = 0, Sent As Double = 0, AllTraffic As Double = 0
    Private Sub Tmr_Tick(sender As Object, e As EventArgs) Handles Tmr.Tick
        ' Статистика для нашего подключения(IPV4)
        StatisticsConnect = Connection.GetIPv4Statistics()
        ' Вычисляем скорость передачи
        Dim TransferRate As Integer
        TransferRate = CInt((Math.Truncate(StatisticsConnect.BytesSent - Double.Parse(BytesSent))) \ 100)
        ' Вычисляем скорость приема
        Dim ReceptionRate As Integer
        ReceptionRate = CInt((Math.Truncate(StatisticsConnect.BytesReceived - Double.Parse(BytesRec))) \ 100)
        ' Значения в байтах
        BytesSent = StatisticsConnect.BytesSent
        BytesRec = StatisticsConnect.BytesReceived
        ' Принято Мб
        Received = Val(StatisticsConnect.BytesReceived) / Val(1024) / Val(1024)
        LbRec.Text = "Принято : " & Math.Round(Received, 2) & " Мб"
        ' Отдано Мб
        Sent = Val(StatisticsConnect.BytesSent) / Val(1024) / Val(1024)
        LbSent.Text = "Передано : " & Math.Round(Sent, 2) & " Мб"
        ' Весь трафик
        LbTraffic.Text = "Весь трафик : " & Math.Round(Received + Sent, 2) & " Мб"
        ' Скорость передачи
        LbSpedPe.Text = "Скорость передачи : " & TransferRate.ToString() & " Кбит/с"
        ' Скорость передачи
        LbSpeedPr.Text = "Скорость приема : " & ReceptionRate.ToString() & " Кбит/с"
    End Sub
End Class
