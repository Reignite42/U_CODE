﻿Imports System.Net.NetworkInformation
Public Class Metro_UIvb
    Dim Connection As NetworkInterface
    Dim ConnectList As NetworkInterface()
    Dim StatisticsConnect As IPv4InterfaceStatistics
    Private Sub Get_Connects()
        MetroComboBox1.Items.Clear()
       
        ' Получаем все подключения
        ConnectList = NetworkInterface.GetAllNetworkInterfaces()
        ' Добавляем имена подключений в ComboBox
        For Each i As NetworkInterface In ConnectList
            If Not i.NetworkInterfaceType = NetworkInterfaceType.Loopback Then
                MetroComboBox1.Items.Add(i.Name)
            End If
        Next
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Get_Connects()
        Form3.Show()
    End Sub
    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles MetroComboBox1.SelectedIndexChanged
        ' Работаем с активным подключением
        Connection = ConnectList(sender.selectedindex)
        MetroLabel10.Text = Connection.Description
        MetroLabel11.Text = Connection.Id
        ' Скорость
        MetroLabel2.Text = "Скорость : " & Val(Connection.Speed) / Val(1000000) & " Мбит/с" ' Скорость в Мб/с
        ' Тик статистики
        Tmr.Start()
        Label1.Text = sender.selectedIndex
    End Sub
    Dim BytesSent As Long = 0, BytesRec As Long = 0
    Dim Received As Double = 0, Sent As Double = 0, AllTraffic As Double = 0
    Private Sub Tmr_Tick(sender As Object, e As EventArgs) Handles Tmr.Tick
        ' Статистика для нашего подключения(IPV4)
        StatisticsConnect = Connection.GetIPv4Statistics()
        ' Вычисляем скорость передачи
        Dim TransferRate As Integer
        TransferRate = CInt((Math.Truncate(StatisticsConnect.BytesSent - Double.Parse(BytesSent))) \ 100)
        ' Вычисляем скорость приема
        Dim ReceptionRate As Integer
        ReceptionRate = CInt((Math.Truncate(StatisticsConnect.BytesReceived - Double.Parse(BytesRec))) \ 100)
        ' Значения в байтах
        BytesSent = StatisticsConnect.BytesSent
        BytesRec = StatisticsConnect.BytesReceived
        ' Принято Мб
        Received = Val(StatisticsConnect.BytesReceived) / Val(1024) / Val(1024)
        If Received >= 1000 Then
            Received = Received / 1024
            MetroLabel4.Text = "Принято : " & Math.Round(Received, 2) & " Гб"
        Else
            MetroLabel4.Text = "Принято : " & Math.Round(Received, 2) & " Мб"
        End If
        ' Отдано Мб
        Sent = Val(StatisticsConnect.BytesSent) / Val(1024) / Val(1024)
        If Sent >= 1000 Then
            Sent = Sent / 1024
            MetroLabel4.Text = "Передано : " & Math.Round(Sent, 2) & " Гб"
        Else
            MetroLabel5.Text = "Передано : " & Math.Round(Sent, 2) & " Мб"
        End If

        ' Весь трафик
        AllTraffic = Val(StatisticsConnect.BytesReceived) / Val(1024) / Val(1024) + Val(StatisticsConnect.BytesSent) / Val(1024) / Val(1024)

        If AllTraffic >= 1000 Then
            AllTraffic = AllTraffic / 1024
            MetroLabel3.Text = "Весь трафик : " & Math.Round(AllTraffic, 2) & " Гб"
        Else
            MetroLabel3.Text = "Весь трафик : " & Math.Round(AllTraffic, 2) & " Мб"

        End If
        ' Скорость передачи
        MetroLabel7.Text = "Скорость передачи : " & TransferRate.ToString() & " Кбит/с"
        ' Скорость передачи
        MetroLabel6.Text = "Скорость приема : " & ReceptionRate.ToString() & " Кбит/с"
    End Sub
    Dim pushed As Boolean = False
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If pushed = True Then
            Button1.Text = "u"
            pushed = False
            Panel1.Hide()
        Else
            Button1.Text = "t"
            pushed = True
            Panel1.Show()
        End If
    End Sub

    Private Sub MetroButton1_Click(sender As Object, e As EventArgs) Handles MetroButton1.Click
        Form2.Show()
    End Sub

    Private Sub NotifyIcon1_DoubleClick(sender As Object, e As EventArgs) Handles NotifyIcon1.DoubleClick
        Me.Show()
        Me.Focus()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Hide()
    End Sub

    Private Sub NotifyIcon1_MouseClick(sender As Object, e As MouseEventArgs) Handles NotifyIcon1.MouseClick
        If e.Button = Windows.Forms.MouseButtons.Left Then
            Form3.Show()
            Form3.Focus()
        End If
    End Sub

    Private Sub ВыходToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ВыходToolStripMenuItem.Click
        Me.Show()
        Me.Focus()
    End Sub

    Private Sub ВыйтиToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ВыйтиToolStripMenuItem.Click
        Application.Exit()
    End Sub
End Class
